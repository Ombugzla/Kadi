// Offline-capable service worker. Code (html/js/css/json) is network-first so updates always show up;
// images and other static assets are cache-first. Bump CACHE whenever you ship a new version.
const CACHE = 'niko-kadi-v18';
const FILES = [
  './', 'index.html', 'manifest.json', 'img/icon.svg', 'img/wood.webp', 'img/icon-192.png', 'img/icon-512.png', 'img/icon-maskable-512.png',
  'css/base.css', 'css/home.css', 'css/table.css', 'css/cards.css', 'css/chat.css',
  'js/main.js', 'js/router.js', 'js/store.js', 'js/screens.js', 'js/chat.js', 'js/ai-chat.js', 'js/ai-chat-config.js', 'js/table.js', 'js/play.js', 'js/playseq.js',
  'js/engine.js', 'js/bots.js', 'js/sequence.js', 'js/cards.js', 'js/avatars.js', 'js/icons.js', 'js/sound.js', 'js/ui.js', 'js/help.js', 'js/rp.js', 'js/legal.js', 'js/online.js',
  ...['royal', 'guilloche', 'deco', 'beads', 'mandala', 'stars'].map((n) => 'img/backs/' + n + '.svg'),
  ...['amara', 'priya', 'luca', 'erik', 'viktor', 'imani', 'mei', 'layla', 'avatar1', 'avatar2', 'avatar3', 'avatar4', 'avatar5', 'avatar6', 'avatar7'].map((n) => 'img/faces/' + n + '.webp'),
];
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => Promise.allSettled(FILES.map((u) => c.add(new Request(u, { cache: 'reload' }))))).then(() => self.skipWaiting())
  );
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  const isCode = e.request.mode === 'navigate' || /\.(?:html|js|css|json)$/.test(url.pathname) || url.pathname.endsWith('/');
  if (isCode) {
    // network-first: fresh files when online, cached copy when offline
    e.respondWith(
      fetch(e.request, { cache: 'no-cache' }).then((res) => {
        if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
        return res;
      }).catch(() => caches.match(e.request).then((hit) => hit || caches.match('index.html')))
    );
    return;
  }
  e.respondWith(caches.match(e.request).then((hit) => hit || fetch(e.request)));
});
