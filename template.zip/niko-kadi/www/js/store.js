// Local profile, stats, history, inbox and settings (localStorage, always wrapped in try/catch).
import { rpDelta, rankInfo } from './rp.js';

const KEY = 'nikokadi.v2';
export const START_RP = 10;

const DEFAULTS = () => ({
  name: 'You',
  avatar: 0, // face index, object id, or 'photo'
  photo: '', // uploaded picture (small data URL)
  rp: START_RP, // rank points, Niko Kadi only
  stats: {
    nk: { played: 0, won: 0, streak: 0, best: 0 },
    ss: { played: 0, won: 0, streak: 0, best: 0 },
  },
  vs: {}, // botId -> { w, l }
  history: [], // recent matches, newest first
  inbox: [], // messages and notifications
  seeded: false,
  streakDays: 0,
  lastDay: '',
  settings: { sound: true, volume: 0.7, haptics: true, reduceMotion: false, back: 'royal', felt: 'parlour', mode: 'light', theme: 'parlour', timer: true },
  rules: { flow: false, specialJK: false, liberal: false },
  game: 'nk',
  level: { nk: 2, ss: 2 }, // index into BOTS
  count: { nk: 2, ss: 2 }, // players at the table (2..4)
  lastBot: { nk: '', ss: '' },
  welcomed: false,
});

let data = null;
function merge(base, src) {
  for (const k of Object.keys(base)) {
    if (src && k in src) {
      if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) merge(base[k], src[k]);
      else base[k] = src[k];
    }
  }
  if (src && src.vs && typeof src.vs === 'object') base.vs = src.vs; // keep dynamic maps
  return base;
}

export function load() {
  if (data) return data;
  let raw = null;
  try { raw = JSON.parse(localStorage.getItem(KEY)); } catch (e) { raw = null; }
  data = merge(DEFAULTS(), raw);
  if (raw && !raw.themeV) { if (!raw.settings || raw.settings.felt === 'teal') data.settings.felt = 'parlour'; }
  data.themeV = 4;
  if (!['royal', 'guilloche', 'deco', 'beads', 'mandala', 'stars'].includes(data.settings.back)) data.settings.back = 'royal';
  for (const m of data.inbox || []) if (m.title === 'Karibu to Niko Kadi') m.title = 'Welcome to Niko Kadi';
  for (const g of ['nk', 'ss']) data.count[g] = Math.max(2, Math.min(4, data.count[g] | 0 || 2)); // table cap: 4
  if (!data.seeded) { seedInbox(); data.seeded = true; }
  return data;
}
export function save() {
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) { /* storage unavailable */ }
}
export const get = () => load();

const dayStr = (t) => new Date(t).toISOString().slice(0, 10);

// Mark today as played (daily streak, shown as the flame).
export function touchDay() {
  const d = load();
  const t = dayStr(Date.now());
  if (d.lastDay !== t) {
    d.streakDays = d.lastDay === dayStr(Date.now() - 864e5) ? d.streakDays + 1 : 1;
    d.lastDay = t;
    save();
  }
}

// ------------------------------------------------------------------ inbox
let seq = 0;
export function addInbox(kind, { from = 'Niko Kadi', title, body }) {
  const d = load();
  d.inbox.unshift({ id: Date.now().toString(36) + (seq++).toString(36), kind, from, title, body, t: Date.now(), read: false });
  if (d.inbox.length > 60) d.inbox.length = 60;
  save();
  try { document.dispatchEvent(new Event('nk:inbox')); } catch (e) { /* no DOM */ }
}
export const inboxOf = (kind) => load().inbox.filter((m) => m.kind === kind);
export const unread = (kind) => load().inbox.filter((m) => !m.read && (!kind || m.kind === kind)).length;
export function markRead(kind, id) {
  const d = load();
  for (const m of d.inbox) if (m.kind === kind && (!id || m.id === id)) m.read = true;
  save();
  try { document.dispatchEvent(new Event('nk:inbox')); } catch (e) { /* no DOM */ }
}
function seedInbox() {
  const d = data;
  const t = Date.now();
  d.inbox.push(
    { id: 'w1', kind: 'msg', from: 'Niko Kadi team', title: 'Welcome to Niko Kadi', body: 'Two games, six computer players from Easy to Expert, and a leaderboard to climb. Pick a game on the home screen and play. The rules are always in More, under How to play.', t, read: false },
    { id: 'w2', kind: 'msg', from: 'Niko Kadi team', title: 'How rank points work', body: 'Win a match and you take 2 RP from every rival at the table. Lose and you pay 2 RP. Beating tougher players is worth more, and losing to them costs less. Your rank title changes as your RP grows.', t: t - 1000, read: false },
    { id: 'w3', kind: 'msg', from: 'Niko Kadi team', title: 'Our fair play promise', body: 'Every shuffle is random and the computer players only use what they can see at the table. Read the full Fair Play Policy in More.', t: t - 2000, read: true },
    { id: 'n1', kind: 'note', from: 'Niko Kadi', title: 'Your rank is Rookie', body: `You start with ${START_RP} RP. Win matches to move up.`, t: t - 500, read: false },
  );
}

// ------------------------------------------------------------------ results
// Record a finished game. Niko Kadi moves RP; Special Sequence earns no rank points.
export function recordResult(game, won, rivals, botId, info = {}) {
  const d = load();
  if (botId) d.lastBot[game] = botId;
  const s = d.stats[game];
  s.played++;
  if (won) { s.won++; s.streak++; s.best = Math.max(s.best, s.streak); } else s.streak = 0;
  let delta = 0, rankUp = null;
  if (game === 'nk') {
    const before = d.rp;
    delta = rpDelta(won, rivals.length + 1, rivals);
    d.rp = Math.max(0, before + delta);
    delta = d.rp - before;
    if (rankInfo(d.rp).idx > rankInfo(before).idx) rankUp = rankInfo(d.rp).name;
  }
  if (botId) {
    const k = game + ':' + botId;
    const v = d.vs[k] || (d.vs[k] = { w: 0, l: 0 });
    if (won) v.w++; else v.l++;
  }
  d.history.unshift({ g: game, t: Date.now(), won, delta, botId, count: rivals.length + 1, names: rivals.map((b) => b.name), winner: info.winner || '', rules: info.rules || null });
  if (d.history.length > 20) d.history.length = 20;
  touchDay();
  const who = rivals.map((b) => b.name).join(', ');
  const gname = game === 'nk' ? 'Niko Kadi' : 'Special Sequence';
  addInbox('note', {
    title: won ? `Victory in ${gname}` : `Defeat in ${gname}`,
    body: won ? `You beat ${who}.${game === 'nk' ? ` +${delta} RP.` : ''}` : `${info.winner || 'A rival'} won.${game === 'nk' && delta ? ` ${delta} RP.` : ''}`,
  });
  if (rankUp) addInbox('note', { title: `Promoted to ${rankUp}`, body: `You reached ${d.rp} RP. Keep climbing the leaderboard.` });
  save();
  return { delta, rp: d.rp, rankUp };
}
